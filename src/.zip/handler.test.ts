// handler.test.js
import { handler } from '.'

describe('Handler', () => {
  it('Deve retornar uma resposta com status 200', async () => {
    const event = {}; // Se necessário, ajuste o evento conforme suas necessidades

    const response = await handler(event);

    expect(response.statusCode).toBe(200);
    expect(typeof response.body).toBe('string');
    expect(response.body).toEqual(expect.stringContaining('Hello from Lambda!'));
  });
});